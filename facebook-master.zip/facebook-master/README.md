# facebook
is a tool for getting Eg , Fr mobile number
# how to use 
choose the carrier and write the last two slot number 
have fun 
# what need to open 
in Linux and Windows need * [__Python 2.7.x__](http://python.org/getit/).
in android need *[__Qpython 2.7.x__](http://qpython.com/).
